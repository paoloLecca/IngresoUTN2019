function Mostrar()
{
	//Genero el número RANDOM entre 1 y 10 
	

}//FIN DE LA FUNCIÓN